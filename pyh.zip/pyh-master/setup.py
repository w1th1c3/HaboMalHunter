#!/usr/bin/env python

from distutils.core import setup

setup(name='PyH',
      version='0.1',
      description='A powerful python module to generate web content',
      author='Emmanuel Turlay',
      author_email='turlay@cern.ch',
      url='http://code/google.com/p/pyh/',
      py_modules=['pyh'],
      )
